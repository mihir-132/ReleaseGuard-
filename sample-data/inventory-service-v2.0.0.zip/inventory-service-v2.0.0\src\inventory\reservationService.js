export function reserveInventory() {
  return { reserved: true };
}
