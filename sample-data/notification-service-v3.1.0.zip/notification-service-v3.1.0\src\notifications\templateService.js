export function renderTemplate(template, data) {
  return template.replace("{name}", data.name ?? "user");
}
