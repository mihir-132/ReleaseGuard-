export function sendSms() {
  return true;
}
