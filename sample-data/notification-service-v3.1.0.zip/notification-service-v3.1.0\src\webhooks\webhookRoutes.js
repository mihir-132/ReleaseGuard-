export function webhookRoutes() {
  return "/api/v1/webhooks";
}
