export function calculateRetryDelay(attempt) {
  return Math.min(attempt * 1000, 30000);
}
