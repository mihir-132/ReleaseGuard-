-- Notification templates
CREATE TABLE notification_templates (
  id INTEGER,
  channel VARCHAR(20),
  template_text TEXT
);
