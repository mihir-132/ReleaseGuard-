-- Stock reconciliation
CREATE TABLE stock_reconciliation (
  id INTEGER,
  warehouse VARCHAR(64),
  reconciled_at TIMESTAMP
);
