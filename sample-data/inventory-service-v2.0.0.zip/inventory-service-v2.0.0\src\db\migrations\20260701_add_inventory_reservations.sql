-- Inventory reservations
CREATE TABLE inventory_reservations (
  id INTEGER,
  sku VARCHAR(64),
  quantity INTEGER
);
